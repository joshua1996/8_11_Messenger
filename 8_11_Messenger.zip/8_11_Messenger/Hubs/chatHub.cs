﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.SignalR;
using System.Diagnostics;
using System.Web.SessionState;
using System.Threading.Tasks;

namespace _8_11_Messenger.Hubs
{
    public class chatHub : Hub, System.Web.SessionState.IRequiresSessionState
    {
        static List<userDetails> connectedUser = new List<userDetails>();

        public void Hello()
        {
            Clients.All.hello();

        }

        public string GetSignalrID()
        {
            if (Context.Request.GetHttpContext().Request.Cookies["userid"] != null)
            {
                return Context.Request.GetHttpContext().Request.Cookies["userid"].Value;
            }
            return "";
        }


        public void send(string name, string message, string dateNow, string groupid)
        {
            Clients.Group(groupid).addNewMessageToPage(name, message, dateNow);
        }

        public void sendTimeAgo(string time)
        {
            Clients.All.changeTimeAgo(time);
        }

        public void connect(string userid)
        {
            GetSignalrID();
            userDetails toUserID = new userDetails();
            var id = Context.ConnectionId;
            Debug.WriteLine(connectedUser.Count);
            if (connectedUser.Count(x => x.connectionID == id) == 0)
            {
                connectedUser.Add(new userDetails { connectionID = id, userID = userid, wantChat = true, groupID = "" });
            }

            userDetails currentUser = connectedUser.Where(u => u.connectionID == id).FirstOrDefault();
            Debug.WriteLine(connectedUser.Where(x => x.groupID == "").Count());
            if (connectedUser.Where(x => x.groupID == "").Count() > 1)
            {
                Random r = new Random();
                string groupID = r.Next(0, 10000).ToString();
                toUserID = connectedUser.Where(x => x.groupID == "").Where(x => x.userID != currentUser.userID).ElementAt(r.Next(0, connectedUser.Where(x => x.groupID == "").Where(x => x.userID != currentUser.userID).Count() - 1));//[r.Next(0, connectedUser.Count - 1)];
                Debug.WriteLine(toUserID.userID);
                Debug.WriteLine(currentUser.userID);
                Debug.WriteLine(groupID);
                Debug.WriteLine(toUserID.connectionID);
                Debug.WriteLine(currentUser.connectionID);
                Debug.WriteLine(Context.ConnectionId);
                Groups.Add(Context.ConnectionId, groupID);
                Groups.Add(toUserID.connectionID, groupID);
                currentUser.groupID = groupID;
                toUserID.groupID = groupID;
                currentUser.wantChat = false;
                toUserID.wantChat = false;
                Clients.Group(groupID).onConnected(groupID, currentUser.connectionID, toUserID.connectionID);
                // Clients.User(GetSignalrID()).onConnected(groupID, currentUser.connectionID, toUserID.connectionID);
            }
        }

        public void reconnect(string groupid, string currentUserID, string toUserID)
        {
            if (groupid != null)
            {
                Groups.Add(Context.ConnectionId, groupid);
            }
            Clients.Caller.onConnected(groupid, currentUserID, toUserID);
        }

        public override System.Threading.Tasks.Task OnDisconnected(bool stopCalled)
        {
            //var item = connectedUser.FirstOrDefault(x => x.connectionID == Context.ConnectionId);
            //if (item != null)
            //{
            //    connectedUser.Remove(item);
            //    if (connectedUser.Where(u => u.userID == item.userID).Count() == 0)
            //    {
            //        var id = item.userID;
            //        //  Clients.All.onUserDisconnected(id, item.userID);
            //    }
            //}
            return base.OnDisconnected(stopCalled);
        }

        public override Task OnConnected()
        {
            return base.OnConnected();
        }

        public string GetUserId(IRequest request)
        {
            return "thisisid";
        }
    }
}

